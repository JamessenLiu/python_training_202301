from django.contrib import admin

from users.models import Users

from django.contrib.auth.models import User, Group
# Register your models here.

admin.site.register(Users)
admin.site.unregister(User)
admin.site.unregister(Group)
