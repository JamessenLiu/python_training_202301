from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q

from users.models import Users


class UsersView(APIView):

    def get(self, request):
        first_name = request.GET.get('firstName', "")
        last_name = request.GET.get('lastName', "")
        offset = int(request.GET.get("offset", 0))
        limit = int(request.GET.get("limit", 10))

        users = Users.objects.filter(
            Q(first_name__icontains=first_name) or
            Q(last_name__icontains=last_name)
        )
        total_count = users.count()
        users = users.values('email')[offset: offset + limit]

        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "list": users,
                "pagination": {
                    "offset": offset,
                    "limit": limit,
                    "totalCount": total_count
                }
            }
        })

    def post(self, request):
        email = request.data.get('email')
        first_name = request.data.get('firstName')
        last_name = request.data.get('lastName')

        _user = Users.objects.filter(email=email).exists()
        if _user:
            return Response({"code": 400})

        user = Users.objects.create(
            email=email,
            first_name=first_name,
            last_name=last_name
        )

        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "userId": user.id
            }
        })


class UserDetailView(APIView):

    def get(self, request, user_id):
        _user = Users.objects.filter(pk=user_id).values("email").first()
        return Response({
            "code": 200,
            "message": "success",
            "data": _user
        })
