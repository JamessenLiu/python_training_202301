from django.db import models
from users.models import Users
from utils.base_model import BaseModel


class Articles(BaseModel):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_length=200)
    content = models.TextField()
    isHot = models.BooleanField()
    article_type = models.SmallIntegerField(choices=((1, "新闻"), (2, "军事"), (3, "娱乐")))
    user_id = models.ForeignKey(Users, related_name="user_articles", on_delete=models.CASCADE)

    class Meta:
        db_table = "articles"
        verbose_name = 'articles'
        verbose_name_plural = 'articles'
