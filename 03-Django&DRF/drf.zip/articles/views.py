from rest_framework.views import APIView
from rest_framework.response import Response
from articles.models import Articles
from users.models import Users


class ArticlesViews(APIView):

    def get(self, request):

        articles = Articles.objects.all().values('title',"subtitle","user_id__email")
        # articles = Articles.objects.all().prefetch_related('user_id')
        # articles_info = []
        # for article in articles:
        #     articles_info.append(
        #         {
        #             "title": article.title,
        #             "subtitle": article.subtitle,
        #             "userEmail": article.user_id.email
        #         }
        #     )
        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "list": articles,

            }
        })


class UserArticleViews(APIView):
    def get(self, request, user_id):
        # articles = Articles.objects.filter(user_id=user_id).values()
        user = Users.objects.get(id=user_id)
        articles = user.user_articles.all().values()
        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "list": articles,

            }
        })
