import requests
from concurrent.futures import ThreadPoolExecutor


class BCServer:

    def __init__(self, store_hash, token):
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Auth-Token": token
        }
        self.base_url = f"https://api.bigcommerce.com/stores/{store_hash}"
        self.session = requests.Session()

    def get_customers(self):
        url = self.base_url + "/v2/customers"
        resp = self.session.get(url, headers=self.headers)
        return resp.json()


bc_server = BCServer("rmz2xgu42d", "jpts4mh09fxfef5ysqcgyyuqnegorgb")
# result = bc_server.get_customers()
# print(result)

import time
start_time = time.time()

# java


# exec = ThreadPoolExecutor(max_workers=10)
# exec.shutdown()

def get_customers_result(bc_server, results):
    result = bc_server.get_customers()
    results.append(result)

results = []
with ThreadPoolExecutor(max_workers=10) as ex:

    for i in range(10):
        result = ex.submit(get_customers_result, bc_server, results)
        # ex.map()
        # print(result.result())
print(results)
# for _ in range(10):
#     result = bc_server.get_customers()
#     print(result)
end_time = time.time()
print(end_time - start_time)
