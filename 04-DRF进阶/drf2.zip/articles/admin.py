from django.contrib import admin
from articles.models import Articles

admin.site.register(Articles)

# Register your models here.
