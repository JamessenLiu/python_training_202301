import time

import jwt
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q

from users.models import Users
from .serializers import UserModelSerializer, CreateUserModelSerializer


class UsersView(APIView):

    def get(self, request):
        first_name = request.GET.get('firstName', "")
        last_name = request.GET.get('lastName', "")
        offset = int(request.GET.get("offset", 0))
        limit = int(request.GET.get("limit", 10))

        # users = Users.objects.filter(
        #     Q(first_name__icontains=first_name) or
        #     Q(last_name__icontains=last_name)
        # )
        # users = Users.objects.filter(
        #     first_name__icontains=first_name,
        #     last_name__icontains=last_name,
        # )
        users = Users.objects.get_queryset().filter_by_fist_name(first_name).filter_by_last_name(last_name)
        total_count = users.count()
        # users = users.values()[offset: offset + limit]
        users = users[offset: offset + limit]
        user_data = UserModelSerializer(users, many=True).data

        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "list": user_data,
                "pagination": {
                    "offset": offset,
                    "limit": limit,
                    "totalCount": total_count
                }
            }
        })

    def post(self, request):
        email = request.data.get('email')
        first_name = request.data.get('firstName')
        last_name = request.data.get('lastName')
        validator = CreateUserModelSerializer(data={
            "email": email,
            "first_name": first_name,
            "last_name": last_name
        })
        if not validator.is_valid():
            return Response(
                {
                    "code": 400,
                    "message": "bad request",
                    "data": validator.errors
                }
            )

        _user = Users.objects.filter(email=email).exists()
        if _user:
            return Response({"code": 400})

        user = Users.objects.create(
            email=email,
            first_name=first_name,
            last_name=last_name
        )

        return Response({
            "code": 200,
            "message": "success",
            "data": {
                "userId": user.id
            }
        })


class UserDetailView(APIView):

    def get(self, request, user_id):
        _user = Users.objects.filter(pk=user_id).values("email").first()
        return Response({
            "code": 200,
            "message": "success",
            "data": _user
        })


class LoginView(APIView):
    authentication_classes = ()

    def post(self, request):
        email = request.data.get("email", "")
        # user = Users.objects.filter(email=email).first()
        user = Users.objects.get_user_by_email(email)
        if not user:
            return Response(
                {
                    "code": 404,
                    "message": "user not found",
                }
            )
        payload = {
            "email": user.email,
            "exp": int(time.time()) + 6000
        }
        token = jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")
        return Response(
            {
                "code": 200,
                "message": "success",
                "data": {
                    "token": token
                }
            }
        )

