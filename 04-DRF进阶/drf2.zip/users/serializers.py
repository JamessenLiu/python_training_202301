from pyexpat import model

from rest_framework import serializers

from users.models import Users


class UserModelSerializer(serializers.ModelSerializer):
    # first_name -> fname
    fname = serializers.CharField(source="first_name")
    # last_name -> lname
    lname = serializers.CharField(source="last_name")

    # username -> first_name + last_name
    username = serializers.SerializerMethodField()

    def get_username(self, obj):
        return obj.first_name + " " + obj.last_name

    class Meta:
        model = Users
        # fields = "__all__"
        # fields = ["id", "email"]
        exclude = ["created_at", "updated_at", "first_name", "last_name"]


class CreateUserModelSerializer(serializers.Serializer):

    email = serializers.EmailField(
        max_length=200,
        allow_blank=False,
        allow_null=False,
        error_messages={
            "max_length": "xxxx",
            "invalid": "邮件格式不对"
        }
    )
    first_name = serializers.CharField(
        max_length=50
    )
    last_name = serializers.CharField(
        max_length=50
    )

    ## first_name 必须a开头，last_name必须b开头
    def validate(self, attrs):
        first_name = attrs['first_name']
        last_name = attrs['last_name']
        if not first_name.startswith("a") or not last_name.startswith("b"):
            raise serializers.ValidationError("名字格式不对")

        return attrs
