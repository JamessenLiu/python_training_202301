from django.db.models import Manager
from django.db.models.query import QuerySet


class UserQuerySet(QuerySet):

    def filter_by_fist_name(self, first_name):
        return self.filter(first_name__icontains=first_name)

    def filter_by_last_name(self, last_name):
        return self.filter(last_name__icontains=last_name)


class UserManager(Manager):

    def get_queryset(self):
        return UserQuerySet(self.model)

    def get_user_by_email(self, email):
        return self.filter(email=email).first()


