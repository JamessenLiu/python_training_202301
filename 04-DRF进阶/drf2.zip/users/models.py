from django.db import models

from users.user_manager import UserManager
from utils.base_model import BaseModel
from django.db.models import Manager


class Users(BaseModel):

    email = models.CharField(max_length=200, unique=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    objects = UserManager()

    class Meta:
        db_table = 'users'
        verbose_name = 'users'
        verbose_name_plural = 'users'
