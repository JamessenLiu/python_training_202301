import jwt
from rest_framework.authentication import BaseAuthentication
from django.conf import settings
from rest_framework.exceptions import AuthenticationFailed

from users.models import Users


class JwtAuthenticate(BaseAuthentication):

    def authenticate(self, request):
        # header -> token
        token = request.META.get('HTTP_TOKEN', "")
        try:
            payload = jwt.decode(token, key=settings.SECRET_KEY, algorithms=['HS256'])
        except:
            raise AuthenticationFailed("invalid token")

        email = payload.get("email", "")
        # user = Users.objects.filter(email=email).first()
        user = Users.objects.get_user_by_email(email)
        if not user:
            raise AuthenticationFailed("user not found")

        user.is_authenticated = True
        request.user = user

        return user, None
